<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="stylesheet.css" >
  <title>Document</title>
</head>
<body>
<header>
    <!-- This paragraph displays a heading about free shipping across Canada for orders over $80 -->
    <p class="heading">Free shipping Across Canada for orders over $80</p>
    <!-- Main Heading -->
    <h1 class="head">Official Carvaan Distributor in Canada </h1>

    <!-- This div with the "menu" ID displays a bars icon using the "fas fa-bars" class -->
    <div id="menu" class="fas fa-bars"></div>

    <!-- Navigation Menu -->
    <nav class="navbar">
        <ul>
            <!-- Navigation links for the website -->
            <li><a href="index.html">home</a></li>
            <li><a href="#">contact</a></li>
            <li><a href="#">Reviews</a></li>
            <li><a href="#">Policy</a></li>
        </ul>
    </nav>
</header>
</body>
</html>