
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="stylesheet.css" >
  <title>Document</title>
</head>
<body>
<footer>
    <div class="footer">
        <!-- Box Container -->
        <div class="box-container">
            <!-- Why Choose Us Box -->
            <div class="box">
                <h3>why choose us?</h3>
                <p>Saregama carvaan is a blessing for the Bollywood music lovers. It's made with simplicity to use. And has a robust built quality with a crisp sound quality.</p>
            </div>
            <!-- Quick Links Box -->
            <div class="box">
                <h3>quick links</h3>
                <a href="index.html">home</a>
                <a href="feedback.html">Feedback</a>
                <a href="contact.html">contact</a>
                <a href="terms.html">Policy</a>
            </div>
            <!-- Newsletter Box -->
            <div class="box">
                <h3>newsletter</h3>
                <p>subscribe us for the latest updates</p>
                <form action="">
                    <!-- Start of Form Section -->
                    <input type="email" placeholder="your email">
                    <!-- Email input field with placeholder -->
                
                    <input type="submit" class="btn" value="subscribe">
                    <!-- Submit button with "subscribe" value and class "btn" -->
                </form>
            </div>
        </div>
        <!-- Credit Line -->
        <h1 class="credit"> created by <a href="#">MiscellaneousGroup</a> | all rights reserved. </h1>
    </div>
</footer>

</body>
</html>